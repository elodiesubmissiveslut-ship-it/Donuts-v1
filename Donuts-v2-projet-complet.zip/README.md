# Donuts Racing App

Application Android WebView qui ouvre le site Donuts Racing.

URL : https://www.donuts-racing.com/fr/

Structure obligatoire à voir sur GitHub :

- app/
- .github/
- build.gradle
- settings.gradle
